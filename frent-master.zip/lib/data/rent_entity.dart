class RentEntity {
  String imageAsset;
  String name;
  String price;
  String rating;
  String spesification;

  RentEntity(
      {this.imageAsset,
      this.name,
      this.price,
      this.rating,
      this.spesification});
}
