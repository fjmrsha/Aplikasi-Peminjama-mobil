package com.example.frent

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
